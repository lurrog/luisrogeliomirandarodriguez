"""
FIA - Actividad Parcial 2 - Sección 3: Búsqueda local (Hill Climbing y Simulated Annealing).

Problema: llenar una mochila de viaje. De 15 objetos hay que elegir cuáles llevar para
maximizar la utilidad total sin pasar el peso máximo de la mochila.

  - Solución (estado): tupla de 15 bits; 1 = llevar el objeto, 0 = dejarlo.
  - Función objetivo f(s): utilidad total si el peso cabe; si se pasa del límite, vale
    -(exceso en kg x 10), así cualquier solución válida es mejor que una inválida.
  - Vecindad: cambiar un solo bit (poner o sacar un objeto).
"""
import math, random, time, itertools, statistics as st

# --------------------------- 1. DATOS DEL PROBLEMA ---------------------------
# (objeto, peso en gramos, utilidad de 1 a 10). Datos ilustrativos.
OBJETOS = [("Laptop", 2200, 9), ("Cargador", 400, 6), ("Ropa de cambio", 1500, 10), ("Chamarra", 1200, 5),
           ("Botiquín", 600, 7), ("Libro", 800, 4), ("Cámara", 900, 6), ("Tenis extra", 1300, 3),
           ("Botella de agua", 1000, 7), ("Snacks", 700, 5), ("Tablet", 600, 5), ("Paraguas", 500, 3),
           ("Bocina portátil", 800, 2), ("Toalla", 900, 3), ("Lentes de sol", 200, 3)]
CAPACIDAD = 7000   # gramos
N = len(OBJETOS)

def peso(s):  return sum(o[1] for b, o in zip(s, OBJETOS) if b)
def valor(s): return sum(o[2] for b, o in zip(s, OBJETOS) if b)

def f(s):
    """Función objetivo (se maximiza)."""
    w = peso(s)
    return valor(s) if w <= CAPACIDAD else -(w - CAPACIDAD) / 100

def vecinos(s):
    """Vecindad: todas las soluciones que difieren en un solo bit."""
    return [s[:i] + (1 - s[i],) + s[i + 1:] for i in range(N)]

def aleatoria(rng): return tuple(rng.randint(0, 1) for _ in range(N))

# --------------------------- 2. HILL CLIMBING --------------------------------
def hill_climbing(s, max_iter=1000):
    """Ascenso de colina de mayor pendiente: en cada paso se mueve al mejor vecino
    y se detiene cuando ningún vecino mejora (óptimo local)."""
    historial = [f(s)]
    for _ in range(max_iter):
        mejor = max(vecinos(s), key=f)
        if f(mejor) <= f(s):
            break
        s = mejor
        historial.append(f(s))
    return s, historial

# --------------------------- 3. SIMULATED ANNEALING --------------------------
def simulated_annealing(s, rng, T0=5.0, eta=0.999, iteraciones=3000):
    """Recocido simulado: en cada iteración se propone un vecino al azar. Si mejora se acepta;
    si empeora, se acepta con probabilidad exp(delta / T). La temperatura baja con T <- eta * T.
    Devuelve la mejor solución vista, su historial de mejor valor y el valor actual por iteración."""
    T, actual = T0, s
    mejor, mejor_v = s, f(s)
    h_mejor, h_actual = [mejor_v], [f(actual)]
    for _ in range(iteraciones):
        i = rng.randrange(N)
        cand = actual[:i] + (1 - actual[i],) + actual[i + 1:]
        delta = f(cand) - f(actual)
        if delta >= 0 or rng.random() < math.exp(delta / T):
            actual = cand
        if f(actual) > mejor_v:
            mejor, mejor_v = actual, f(actual)
        h_mejor.append(mejor_v); h_actual.append(f(actual))
        T *= eta
    return mejor, h_mejor, h_actual

# --------------------------- 4. REFERENCIA EXACTA ----------------------------
def optimo_exacto():
    """Fuerza bruta sobre las 2^15 combinaciones (solo para validar los resultados)."""
    return max(itertools.product((0, 1), repeat=N), key=f)

# --------------------------- 5. EXPERIMENTO ----------------------------------
def experimento(corridas=30, semilla=2026, T0=5.0, eta=0.999, iteraciones=3000):
    rng = random.Random(semilla)
    res = {"hc": [], "sa": [], "hc_h": [], "sa_h": [], "sa_act": [], "t_hc": 0.0, "t_sa": 0.0}
    for _ in range(corridas):
        s0 = aleatoria(rng)                        # mismo punto de partida para ambos
        t = time.perf_counter(); s, h = hill_climbing(s0); res["t_hc"] += time.perf_counter() - t
        res["hc"].append(s); res["hc_h"].append(h)
        t = time.perf_counter(); s, hm, ha = simulated_annealing(s0, rng, T0, eta, iteraciones); res["t_sa"] += time.perf_counter() - t
        res["sa"].append(s); res["sa_h"].append(hm); res["sa_act"].append(ha)
    return res

def resumen(sols, opt_v):
    v = [f(s) for s in sols]
    return dict(media=st.mean(v), desv=st.pstdev(v), mejor=max(v), peor=min(v),
                pct_opt=100 * sum(1 for x in v if x == opt_v) / len(v), valores=v)

def sensibilidad_eta(etas=(0.99, 0.995, 0.999), corridas=30, semilla=2026, T0=5.0, iteraciones=3000):
    opt_v = f(optimo_exacto()); filas = []
    for eta in etas:
        r = experimento(corridas, semilla, T0, eta, iteraciones)
        rs = resumen(r["sa"], opt_v); filas.append((eta, rs["media"], rs["mejor"], rs["pct_opt"]))
    return filas

def main():
    opt = optimo_exacto(); opt_v = f(opt)
    print(f"Óptimo exacto (fuerza bruta, {2**N:,} combinaciones): utilidad {opt_v}, peso {peso(opt)} g")
    print("Objetos del óptimo:", ", ".join(o[0] for b, o in zip(opt, OBJETOS) if b))
    r = experimento()
    for nombre, clave, t in (("Hill Climbing", "hc", r["t_hc"]), ("Simulated Annealing", "sa", r["t_sa"])):
        s = resumen(r[clave], opt_v)
        print(f"{nombre:<20} media={s['media']:.2f} desv={s['desv']:.2f} mejor={s['mejor']} peor={s['peor']} "
              f"%óptimo={s['pct_opt']:.0f}% tiempo total={t:.3f}s")
    print("Pasos de HC (media):", round(st.mean(len(h) - 1 for h in r["hc_h"]), 1))
    print("Sensibilidad al factor de enfriamiento eta (T0=5, 3000 iteraciones):")
    for eta, media, mejor, pct in sensibilidad_eta():
        print(f"  eta={eta}: media={media:.2f} mejor={mejor} %óptimo={pct:.0f}%")
    return opt, r

if __name__ == "__main__":
    main()