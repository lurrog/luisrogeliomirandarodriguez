"""Gráficas de la Sección 3 (todo en blanco y negro)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seccion3_busqueda_local as m

plt.rcParams.update({"text.color": "black", "axes.edgecolor": "black", "axes.labelcolor": "black",
                     "xtick.color": "black", "ytick.color": "black", "font.size": 9})

def convergencia(r, opt_v, archivo):
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2), dpi=170)
    for h in r["hc_h"]:
        ax[0].plot(range(len(h)), h, color="black", lw=0.8, marker="o", ms=3, alpha=0.8)
    ax[0].axhline(opt_v, color="black", ls="--", lw=1.2, label=f"Óptimo exacto ({opt_v})")
    ax[0].set_title("(a) Hill Climbing: 30 corridas", fontsize=10, fontweight="bold")
    ax[0].set_xlabel("Paso (movimiento al mejor vecino)"); ax[0].set_ylabel("Valor de la función objetivo")
    ax[0].legend(frameon=False, loc="lower right")
    ax[0].set_xticks(range(0, max(len(h) for h in r["hc_h"])))
    H = np.array(r["sa_h"]); x = np.arange(H.shape[1])
    ax[1].fill_between(x, H.min(0), H.max(0), facecolor="none", edgecolor="black", hatch="////", lw=0, label="Rango de las 30 corridas")
    ax[1].plot(r["sa_act"][0], color="black", lw=0.4, label="Valor actual (corrida 1)")
    ax[1].plot(x, H.mean(0), color="black", lw=2.2, label="Mejor valor, media de 30 corridas")
    ax[1].axhline(opt_v, color="black", ls="--", lw=1.2, label=f"Óptimo exacto ({opt_v})")
    ax[1].set_ylim(-5, opt_v + 3)
    ax[1].set_title("(b) Simulated Annealing: T0 = 5, eta = 0.999", fontsize=10, fontweight="bold")
    ax[1].set_xlabel("Iteración"); ax[1].set_ylabel("Valor de la función objetivo")
    ax[1].legend(frameon=False, loc="lower right", fontsize=7.5)
    fig.tight_layout(); fig.savefig(archivo); plt.close(fig)

def cajas(rs_hc, rs_sa, opt_v, archivo):
    fig, ax = plt.subplots(figsize=(5.2, 4.2), dpi=170)
    bp = ax.boxplot([rs_hc["valores"], rs_sa["valores"]], widths=0.5, patch_artist=True, tick_labels=["Hill Climbing", "Simulated Annealing"],
                    medianprops=dict(color="black", lw=2), boxprops=dict(facecolor="white", edgecolor="black"),
                    whiskerprops=dict(color="black"), capprops=dict(color="black"), flierprops=dict(markeredgecolor="black"))
    bp["boxes"][1].set_hatch("///")
    ax.axhline(opt_v, color="black", ls="--", lw=1.2); ax.text(1.5, opt_v + 0.4, f"Óptimo exacto = {opt_v}", ha="center", fontsize=8)
    ax.set_ylabel("Valor final de la función objetivo"); ax.set_title("Resultado final en 30 corridas", fontsize=10, fontweight="bold")
    fig.tight_layout(); fig.savefig(archivo); plt.close(fig)

def sensibilidad(filas, archivo, T0=5.0, iteraciones=3000):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.8), dpi=170)
    estilos = {0.99: ":", 0.995: "--", 0.999: "-"}
    it = np.arange(iteraciones + 1)
    for eta, *_ in filas:
        ax[0].plot(it, T0 * eta ** it, color="black", ls=estilos[eta], lw=1.6, label=f"eta = {eta}")
    ax[0].set_yscale("log"); ax[0].set_xlabel("Iteración"); ax[0].set_ylabel("Temperatura T (escala log)")
    ax[0].set_title("(a) Enfriamiento según eta", fontsize=10, fontweight="bold"); ax[0].legend(frameon=False)
    etiquetas = [str(f[0]) for f in filas]; vals = [f[3] for f in filas]
    barras = ax[1].bar(etiquetas, vals, facecolor="white", edgecolor="black", hatch="//", lw=1.2)
    for b, v in zip(barras, vals): ax[1].text(b.get_x() + b.get_width() / 2, v + 1.5, f"{v:.0f}%", ha="center", fontsize=9)
    ax[1].set_ylim(0, 100); ax[1].set_xlabel("eta"); ax[1].set_ylabel("Corridas que llegan al óptimo (%)")
    ax[1].set_title("(b) Efecto de eta en la calidad", fontsize=10, fontweight="bold")
    fig.tight_layout(); fig.savefig(archivo); plt.close(fig)

if __name__ == "__main__":
    opt = m.optimo_exacto(); opt_v = m.f(opt); r = m.experimento()
    rs_hc, rs_sa = m.resumen(r["hc"], opt_v), m.resumen(r["sa"], opt_v)
    convergencia(r, opt_v, "fig_convergencia.png"); cajas(rs_hc, rs_sa, opt_v, "fig_cajas.png")
    sensibilidad(m.sensibilidad_eta(), "fig_sensibilidad.png"); print("figuras ok")