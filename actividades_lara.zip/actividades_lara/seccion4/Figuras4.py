"""Figuras de la Sección 4 (todo en blanco y negro)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seccion4_bfs_dfs as m

plt.rcParams.update({"text.color": "black", "axes.edgecolor": "black", "axes.labelcolor": "black",
                     "xtick.color": "black", "ytick.color": "black", "font.size": 9})

def dibujar(ax, d, alg, titulo):
    lab = d["lab"]; n = len(lab)
    img = np.array([[1 if x == "#" else 0 for x in f] for f in lab])
    ax.imshow(img, cmap="gray_r", vmin=0, vmax=1, interpolation="nearest")
    r = d["res"][alg]
    ex = [p for p in r["orden"] if p not in (d["ini"], d["meta"])]
    ax.scatter([p[1] for p in ex], [p[0] for p in ex], s=5, c="black", marker="o", zorder=2)
    # las casillas exploradas se ven como puntos; el camino solución como línea gruesa
    ax.plot([p[1] for p in r["camino"]], [p[0] for p in r["camino"]], color="black", lw=4.6, zorder=3)
    ax.plot([p[1] for p in r["camino"]], [p[0] for p in r["camino"]], color="white", lw=2.0, zorder=4)
    for (pos, txt) in ((d["ini"], "S"), (d["meta"], "G")):
        ax.text(pos[1], pos[0], txt, ha="center", va="center", fontsize=8, fontweight="bold",
                bbox=dict(boxstyle="square,pad=0.2", fc="white", ec="black", lw=1.2), zorder=5)
    ax.set_title(titulo, fontsize=10, fontweight="bold"); ax.axis("off")

def laberinto(d, nombre, archivo):
    fig, ax = plt.subplots(1, 2, figsize=(11, 5.9), dpi=170)
    for a, alg in zip(ax, ("BFS", "DFS")):
        r = d["res"][alg]
        dibujar(a, d, alg, f"{alg}: {r['pasos']} pasos, {r['expandidos']} nodos expandidos")
    fig.text(0.5, 0.015, "Puntos = casillas expandidas   Línea con contorno = camino encontrado   S = inicio   G = meta   Negro sólido = pared",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, 0.04, 1, 0.97)); fig.savefig(archivo); plt.close(fig)

def comparacion(salida, archivo):
    fig, ax = plt.subplots(1, 3, figsize=(11, 3.6), dpi=170)
    metricas = [("expandidos", "Nodos expandidos"), ("pasos", "Longitud del camino (pasos)"),
                ("max_estructura", "Tamaño máx. de cola o pila")]
    x = np.arange(2); w = 0.36
    for a, (k, tit) in zip(ax, metricas):
        for i, (alg, hatch) in enumerate((("BFS", ""), ("DFS", "////"))):
            vals = [salida[l]["res"][alg][k] for l in ("A", "B")]
            bars = a.bar(x + (i - 0.5) * w, vals, w, facecolor="white", edgecolor="black", hatch=hatch, lw=1.2, label=alg)
            for b, v in zip(bars, vals): a.text(b.get_x() + b.get_width()/2, v, str(v), ha="center", va="bottom", fontsize=8)
        a.set_xticks(x); a.set_xticklabels(["Laberinto A\n(con ciclos)", "Laberinto B\n(sin ciclos)"])
        a.set_title(tit, fontsize=9.5, fontweight="bold"); a.margins(y=0.15)
    ax[0].legend(frameon=False, loc="upper right")
    fig.tight_layout(); fig.savefig(archivo); plt.close(fig)

if __name__ == "__main__":
    s = m.main()
    laberinto(s["A"], "A", "fig_lab_A.png"); laberinto(s["B"], "B", "fig_lab_B.png"); comparacion(s, "fig_comparacion.png")
    print("figuras ok")