"""
FIA - Actividad Parcial 2 - Sección 4: Búsqueda ciega (BFS y DFS).

Se resuelven dos laberintos de 31 x 31 casillas con Búsqueda en Anchura (BFS) y Búsqueda en
Profundidad (DFS). El laberinto se representa como un grafo no dirigido: cada casilla libre es un
nodo y hay una arista entre casillas libres adyacentes (arriba, derecha, abajo, izquierda), con
costo 1 por movimiento.
  - Laberinto A: tiene ciclos (varios caminos posibles).
  - Laberinto B: perfecto, sin ciclos (un único camino entre dos casillas).
"""
import random, time, itertools, statistics as st
from collections import deque
import networkx as nx

DIRS = {"arriba": (-1, 0), "derecha": (0, 1), "abajo": (1, 0), "izquierda": (0, -1)}
ORDEN_BASE = ("arriba", "derecha", "abajo", "izquierda")

# ------------------------- 1. GENERACIÓN DEL LABERINTO -------------------------
def generar_laberinto(n, semilla, prob_ciclos=0.0):
    """Laberinto de n x n (n impar) con el algoritmo de retroceso (backtracker).
    '#' = pared, ' ' = libre. Con prob_ciclos > 0 se derriban paredes intermedias para crear ciclos."""
    rng = random.Random(semilla)
    g = [["#"] * n for _ in range(n)]
    g[1][1] = " "; pila = [(1, 1)]
    while pila:
        r, c = pila[-1]
        vec = [(r + 2*dr, c + 2*dc, dr, dc) for dr, dc in DIRS.values()
               if 0 < r + 2*dr < n - 1 and 0 < c + 2*dc < n - 1 and g[r + 2*dr][c + 2*dc] == "#"]
        if vec:
            nr, nc, dr, dc = rng.choice(vec)
            g[r + dr][c + dc] = " "; g[nr][nc] = " "; pila.append((nr, nc))
        else:
            pila.pop()
    for r in range(1, n - 1):
        for c in range(1, n - 1):
            if g[r][c] == "#" and (r + c) % 2 == 1 and rng.random() < prob_ciclos:
                if (g[r-1][c] == " " and g[r+1][c] == " ") or (g[r][c-1] == " " and g[r][c+1] == " "):
                    g[r][c] = " "
    return ["".join(f) for f in g], (1, 1), (n - 2, n - 2)

# ------------------------- 2. REPRESENTACIÓN COMO GRAFO ------------------------
def construir_grafo(lab, orden=ORDEN_BASE):
    """Lista de adyacencia {casilla: [vecinos]}; el orden de los vecinos sigue `orden`."""
    adj = {}
    for r, fila in enumerate(lab):
        for c, x in enumerate(fila):
            if x == " ":
                adj[(r, c)] = [(r + DIRS[d][0], c + DIRS[d][1]) for d in orden
                               if lab[r + DIRS[d][0]][c + DIRS[d][1]] == " "]
    return adj

def reconstruir(padre, meta):
    camino, u = [], meta
    while u is not None:
        camino.append(u); u = padre[u]
    return camino[::-1]

# ------------------------- 3. BFS ----------------------------------------------
def bfs(adj, inicio, meta):
    """Búsqueda en anchura: cola FIFO. Devuelve (camino, expandidos, max_frontera, orden_expansion)."""
    frontera, padre = deque([inicio]), {inicio: None}
    expandidos, max_f, orden = 0, 1, []
    while frontera:
        u = frontera.popleft(); expandidos += 1; orden.append(u)
        if u == meta:
            return reconstruir(padre, u), expandidos, max_f, orden
        for v in adj[u]:
            if v not in padre:               # evita estados repetidos
                padre[v] = u; frontera.append(v)
        max_f = max(max_f, len(frontera))
    return None, expandidos, max_f, orden

# ------------------------- 4. DFS ----------------------------------------------
def dfs(adj, inicio, meta):
    """Búsqueda en profundidad (iterativa): pila LIFO. Un nodo se marca al sacarlo de la pila."""
    pila, padre = [(inicio, None)], {}
    expandidos, max_p, orden = 0, 1, []
    while pila:
        u, p = pila.pop()
        if u in padre:
            continue
        padre[u] = p; expandidos += 1; orden.append(u)
        if u == meta:
            return reconstruir(padre, u), expandidos, max_p, orden
        for v in reversed(adj[u]):           # así se explora primero el primer vecino de la lista
            if v not in padre:
                pila.append((v, u))
        max_p = max(max_p, len(pila))
    return None, expandidos, max_p, orden

# ------------------------- 5. MEDICIONES ---------------------------------------
def medir_ms(algoritmo, adj, inicio, meta, repeticiones=200):
    t = time.perf_counter()
    for _ in range(repeticiones):
        algoritmo(adj, inicio, meta)
    return (time.perf_counter() - t) / repeticiones * 1000

def evaluar(adj, inicio, meta):
    res = {}
    for nombre, alg in (("BFS", bfs), ("DFS", dfs)):
        camino, exp, mem, orden = alg(adj, inicio, meta)
        res[nombre] = dict(camino=camino, pasos=len(camino) - 1, expandidos=exp, max_estructura=mem,
                           ms=medir_ms(alg, adj, inicio, meta), orden=orden)
    return res

def validar(adj, inicio, meta, res):
    """BFS debe coincidir con el camino más corto de NetworkX; ambos caminos deben ser válidos."""
    G = nx.Graph(adj)
    assert res["BFS"]["pasos"] == nx.shortest_path_length(G, inicio, meta)
    for nombre in ("BFS", "DFS"):
        cam = res[nombre]["camino"]
        assert cam[0] == inicio and cam[-1] == meta and all(b in adj[a] for a, b in zip(cam, cam[1:]))

def datos_grafo(adj):
    V = len(adj); E = sum(len(v) for v in adj.values()) // 2
    return V, E, 2 * E / V

def sensibilidad_dfs(lab, inicio, meta):
    """DFS con las 24 permutaciones posibles del orden de vecinos."""
    filas = []
    for orden in itertools.permutations(ORDEN_BASE):
        adj = construir_grafo(lab, orden)
        cam, exp, _, _ = dfs(adj, inicio, meta)
        filas.append((orden, len(cam) - 1, exp))
    return filas

# ------------------------- 6. PRINCIPAL ----------------------------------------
LABERINTOS = {"A": dict(n=31, semilla=4, prob_ciclos=0.12), "B": dict(n=31, semilla=4, prob_ciclos=0.0)}

def main():
    salida = {}
    for nombre, cfg in LABERINTOS.items():
        lab, ini, meta = generar_laberinto(**cfg)
        adj = construir_grafo(lab)
        V, E, b = datos_grafo(adj)
        res = evaluar(adj, ini, meta); validar(adj, ini, meta, res)
        print(f"\n=== Laberinto {nombre} ({cfg['n']}x{cfg['n']}, prob. de ciclos {cfg['prob_ciclos']}) ===")
        print(f"Nodos |V| = {V}, aristas |E| = {E}, grado medio = {b:.2f}, ciclos independientes = {E - V + 1}")
        for alg in ("BFS", "DFS"):
            r = res[alg]
            print(f"{alg}: pasos = {r['pasos']}, nodos expandidos = {r['expandidos']}, "
                  f"tamaño máx. de {'cola' if alg == 'BFS' else 'pila'} = {r['max_estructura']}, tiempo = {r['ms']:.3f} ms")
        sens = sensibilidad_dfs(lab, ini, meta)
        pasos = [s[1] for s in sens]; exps = [s[2] for s in sens]
        print(f"DFS con las 24 órdenes de vecinos: pasos min/media/máx = {min(pasos)}/{st.mean(pasos):.1f}/{max(pasos)}; "
              f"expandidos min/media/máx = {min(exps)}/{st.mean(exps):.1f}/{max(exps)}")
        salida[nombre] = dict(lab=lab, ini=ini, meta=meta, adj=adj, V=V, E=E, b=b, res=res, sens=sens)
    return salida

if __name__ == "__main__":
    main()