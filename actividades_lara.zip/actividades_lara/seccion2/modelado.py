"""
FIA - Actividad Parcial 2 - Sección 2: Problemas y espacios de búsqueda.

Modela dos problemas reales como problemas de búsqueda (estado inicial, acciones,
modelo de transición, costo y test de meta) y construye su espacio de estados
como un grafo dirigido y ponderado con NetworkX.

  Problema 1: ruta en la red del Metro de la CDMX (La Paz -> Chabacano).
  Problema 2: reparto de última milla (almacén + 4 clientes, regreso al almacén).
"""
from collections import deque
from itertools import permutations
from math import comb
import networkx as nx

# =====================================================================
# 1. GENERADOR GENÉRICO DE ESPACIO DE ESTADOS
# =====================================================================
def generar_espacio_estados(inicial, sucesores):
    """Explora todos los estados alcanzables desde `inicial` (búsqueda en anchura)
    usando la función `sucesores(estado)` -> iterable de (accion, nuevo_estado, costo).
    Devuelve un DiGraph: nodos = estados, aristas = acciones con atributo 'weight' (costo)."""
    G = nx.DiGraph()
    G.add_node(inicial)
    frontera, vistos = deque([inicial]), {inicial}
    while frontera:
        estado = frontera.popleft()
        for accion, nuevo, costo in sucesores(estado):
            G.add_edge(estado, nuevo, weight=costo, accion=accion)
            if nuevo not in vistos:          # evita repetir estados (búsqueda en grafo)
                vistos.add(nuevo)
                frontera.append(nuevo)
    return G

# =====================================================================
# 2. PROBLEMA 1: RUTA EN EL METRO DE LA CDMX
# =====================================================================
# Subred modelada (orden de estaciones verificado en fuentes públicas).
LINEAS = {
    "A": ["Pantitlán", "Agrícola Oriental", "Canal de San Juan", "Tepalcates", "Guelatao",
          "Peñón Viejo", "Acatitla", "Santa Marta", "Los Reyes", "La Paz"],
    "1": ["Pantitlán", "Zaragoza", "Gómez Farías", "Boulevard Puerto Aéreo", "Balbuena",
          "Moctezuma", "San Lázaro", "Candelaria", "Merced", "Pino Suárez"],
    "9": ["Pantitlán", "Puebla", "Ciudad Deportiva", "Velódromo", "Mixiuhca", "Jamaica", "Chabacano"],
    "4": ["Candelaria", "Fray Servando", "Jamaica"],
}
T_TRAMO = 2         # minutos entre estaciones adyacentes (supuesto del modelo)
T_TRANSBORDO = 5    # minutos por transbordo entre líneas (supuesto del modelo)

def sucesores_metro(estado, cerrados=frozenset()):
    """Estado = (estación, línea en la que va el pasajero).
    Acciones: avanzar a la estación adyacente de la misma línea, o transbordar."""
    estacion, linea = estado
    ruta = LINEAS[linea]
    i = ruta.index(estacion)
    for j in (i - 1, i + 1):                                   # avanzar
        if 0 <= j < len(ruta) and (ruta[j], linea) not in cerrados:
            yield f"Ir a {ruta[j]} (Línea {linea})", (ruta[j], linea), T_TRAMO
    for otra, est_otra in LINEAS.items():                      # transbordar
        if otra != linea and estacion in est_otra and (estacion, otra) not in cerrados:
            yield f"Transbordar a Línea {otra} en {estacion}", (estacion, otra), T_TRANSBORDO

def espacio_metro(origen=("La Paz", "A"), cerrados=frozenset()):
    return generar_espacio_estados(origen, lambda s: sucesores_metro(s, cerrados))

# =====================================================================
# 3. PROBLEMA 2: REPARTO DE ÚLTIMA MILLA (almacén + 4 clientes)
# =====================================================================
CLIENTES = ("C1", "C2", "C3", "C4")
# Distancias en km (datos ilustrativos, simétricas). "D" = almacén.
DIST = {("D","C1"):4, ("D","C2"):6, ("D","C3"):7, ("D","C4"):5,
        ("C1","C2"):7, ("C1","C3"):3, ("C1","C4"):8,
        ("C2","C3"):6, ("C2","C4"):3, ("C3","C4"):4}
def d(a, b): return DIST.get((a, b)) or DIST[(b, a)]

def sucesores_entrega(estado):
    """Estado = (ubicación actual, clientes ya atendidos).
    Acciones: ir a un cliente pendiente; si ya no hay pendientes, regresar al almacén."""
    ubicacion, atendidos = estado
    pendientes = [c for c in CLIENTES if c not in atendidos]
    for c in pendientes:
        yield f"Entregar en {c}", (c, atendidos | {c}), d(ubicacion, c)
    if not pendientes and ubicacion != "D":
        yield "Regresar al almacén", ("D", atendidos), d(ubicacion, "D")

ESTADO_INICIAL_ENTREGA = ("D", frozenset())
def meta_entrega(estado): return estado[0] == "D" and len(estado[1]) == len(CLIENTES)

def espacio_entrega():
    return generar_espacio_estados(ESTADO_INICIAL_ENTREGA, sucesores_entrega)

def costo_tour(orden):                       # fuerza bruta para validar el modelo
    ruta = ("D",) + orden + ("D",)
    return sum(d(a, b) for a, b in zip(ruta, ruta[1:]))

# --- tamaños teóricos del espacio de estados del problema 2 ---
def n_estados_entrega(n): return 2 + n * 2 ** (n - 1)
def n_aristas_entrega(n):
    return n + sum(n * comb(n - 1, k - 1) * (n - k) for k in range(1, n)) + n

# =====================================================================
# 4. PRUEBA Y RESULTADOS
# =====================================================================
def resolver(G, origen, meta):
    camino = nx.dijkstra_path(G, origen, meta, weight="weight")
    costo = nx.dijkstra_path_length(G, origen, meta, weight="weight")
    acciones = [G[a][b]["accion"] for a, b in zip(camino, camino[1:])]
    return camino, costo, acciones

def main():
    print("=== PROBLEMA 1: Metro CDMX (La Paz -> Chabacano) ===")
    destino = ("Chabacano", "9")
    G1 = espacio_metro()
    c1, k1, a1 = resolver(G1, ("La Paz", "A"), destino)
    print(f"Estados |V| = {G1.number_of_nodes()}, acciones |E| = {G1.number_of_edges()}, "
          f"grado de salida medio b = {G1.number_of_edges()/G1.number_of_nodes():.2f}")
    print(f"Costo óptimo = {k1} min, profundidad de la solución d = {len(a1)} acciones")
    print("Plan:", " | ".join(a1))

    cerrados = frozenset({("Pantitlán", "9"), ("Puebla", "9"), ("Ciudad Deportiva", "9")})
    G1c = espacio_metro(cerrados=cerrados)
    c1c, k1c, a1c = resolver(G1c, ("La Paz", "A"), destino)
    print(f"\nEscenario con cierre Pantitlán-Puebla-Ciudad Deportiva (L9): |V| = {G1c.number_of_nodes()}, "
          f"|E| = {G1c.number_of_edges()}, costo = {k1c} min, d = {len(a1c)}")
    print("Plan:", " | ".join(a1c))

    print("\n=== PROBLEMA 2: Reparto (almacén + 4 clientes) ===")
    G2 = espacio_entrega()
    meta = ("D", frozenset(CLIENTES))
    c2, k2, a2 = resolver(G2, ESTADO_INICIAL_ENTREGA, meta)
    print(f"Estados |V| = {G2.number_of_nodes()} (fórmula 2 + n*2^(n-1) = {n_estados_entrega(4)}), "
          f"acciones |E| = {G2.number_of_edges()} (fórmula = {n_aristas_entrega(4)})")
    print(f"Costo óptimo = {k2} km, profundidad d = {len(a2)} acciones")
    print("Plan:", " | ".join(a2))
    mejor = min(permutations(CLIENTES), key=costo_tour)
    print(f"Validación por fuerza bruta ({len(list(permutations(CLIENTES)))} permutaciones): "
          f"{mejor} con {costo_tour(mejor)} km -> {'COINCIDE' if costo_tour(mejor) == k2 else 'NO COINCIDE'}")
    assert costo_tour(mejor) == k2 and meta_entrega(c2[-1])

    print("\nCrecimiento del espacio (problema 2):  n | estados | aristas | permutaciones n!")
    from math import factorial
    for n in (4, 6, 8, 10, 12, 15):
        print(f"  {n:>2} | {n_estados_entrega(n):>10,} | {n_aristas_entrega(n):>12,} | {factorial(n):>16,}")
    return dict(G1=G1, c1=c1, k1=k1, a1=a1, G1c=G1c, c1c=c1c, k1c=k1c, a1c=a1c, G2=G2, c2=c2, k2=k2, a2=a2)

if __name__ == "__main__":
    main()