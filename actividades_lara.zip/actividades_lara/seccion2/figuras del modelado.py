"""Diagramas de los grafos de la Sección 2 (matplotlib + NetworkX)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import seccion2_modelado as m

COL = {"A": "#8e3b9e", "1": "#e8508a", "9": "#8a5a2b", "4": "#2bb5c9"}

def pos_base():
    p = {}
    for i, e in enumerate(m.LINEAS["A"][1:], 1): p[e] = (i * 0.95, -0.12 * i)
    p["Pantitlán"] = (0, 0)
    L1 = [(-1,0.3),(-2,0.6),(-3,0.9),(-4,1.2),(-5,1.4),(-6,1.55),(-7,1.6),(-8,1.6),(-9,1.6)]
    for e, xy in zip(m.LINEAS["1"][1:], L1): p[e] = xy
    L9 = [(-1,-0.3),(-2,-0.6),(-3,-0.9),(-4,-1.2),(-5.5,-1.5),(-7.2,-1.7)]
    for e, xy in zip(m.LINEAS["9"][1:], L9): p[e] = xy
    p["Fray Servando"] = (-6.3, 0.1)
    return p
OFF = {"A": (0.22, -0.05), "1": (0.0, 0.24), "9": (0.0, -0.24), "4": (0.24, 0.0)}

def pos_estado(nodos):
    base = pos_base()
    multi = {e for e in base if sum(e in v for v in m.LINEAS.values()) > 1}
    return {(e, l): (base[e][0] + (OFF[l][0] if e in multi else 0), base[e][1] + (OFF[l][1] if e in multi else 0))
            for (e, l) in nodos}

def dibujar_metro(G, camino, titulo, archivo, cerrados=()):
    fig, ax = plt.subplots(figsize=(13, 6.2), dpi=170)
    pos = pos_estado(G.nodes); base = pos_base()
    for u, v, dat in G.edges(data=True):
        if u[1] == v[1]:   # tramo en la misma línea
            ax.plot(*zip(pos[u], pos[v]), color=COL[u[1]], lw=3, solid_capstyle="round", zorder=1)
        else:              # transbordo
            ax.plot(*zip(pos[u], pos[v]), color="#444", lw=1.3, ls=(0, (2, 2)), zorder=2)
    for u, v in zip(camino, camino[1:]):
        ax.plot(*zip(pos[u], pos[v]), color="#ffc400", lw=7, alpha=.75, zorder=0, solid_capstyle="round")
    for n in G.nodes:
        ax.scatter(*pos[n], s=46, c="white", edgecolors=COL[n[1]], linewidths=2, zorder=3)
    for n in cerrados:
        ax.scatter(*pos_estado([n])[n], s=130, marker="X", c="#d32f2f", zorder=4)
    ax.scatter(*pos[camino[0]], s=190, marker="o", c="#2e7d32", zorder=5)
    ax.scatter(*pos[camino[-1]], s=190, marker="*", c="#c62828", zorder=5)
    for e, (x, y) in base.items():
        arriba = e in m.LINEAS["1"] or e == "Fray Servando"
        ax.text(x, y + (0.34 if arriba else -0.34), e, fontsize=6.3, rotation=35,
                ha="left" if arriba else "right", va="bottom" if arriba else "top", color="#222")
    for l, (x, y) in {"A": (9.2, -1.35), "1": (-9.4, 2.0), "9": (-3.4, -0.1), "4": (-7.9, 0.4)}.items():
        ax.text(x, y, f"Línea {l}", color="white", fontsize=8, fontweight="bold", ha="center",
                bbox=dict(boxstyle="round,pad=0.25", fc=COL[l], ec="none"))
    ax.set_title(titulo, fontsize=12, fontweight="bold", color="#2b1b6b")
    ax.text(0.01, 0.02, "Círculo verde = estado inicial   Estrella roja = meta   Franja amarilla = camino óptimo (Dijkstra)   "
            "Línea punteada = transbordo", transform=ax.transAxes, fontsize=7.5, color="#444")
    ax.set_xlim(-10, 10.2); ax.set_ylim(-3.0, 2.6); ax.axis("off")
    fig.tight_layout(); fig.savefig(archivo); plt.close(fig)

def dibujar_entrega_base(archivo):
    G = nx.Graph()
    for (a, b), w in m.DIST.items(): G.add_edge(a, b, weight=w)
    pos = {"D": (0, 0), "C1": (-1.4, 1.2), "C2": (1.5, 1.4), "C3": (-1.1, -1.3), "C4": (1.6, -1.1)}
    fig, ax = plt.subplots(figsize=(5.6, 4.2), dpi=170)
    nx.draw_networkx_edges(G, pos, ax=ax, edge_color="#9a93c8", width=1.8)
    nx.draw_networkx_edge_labels(G, pos, nx.get_edge_attributes(G, "weight"), ax=ax, font_size=9,
                                 bbox=dict(fc="white", ec="none", pad=0.5))
    nx.draw_networkx_nodes(G, pos, ax=ax, node_color=["#2b1b6b" if n == "D" else "#1ab2d9" for n in G.nodes],
                           node_size=900, edgecolors="white")
    nx.draw_networkx_labels(G, pos, ax=ax, font_color="white", font_weight="bold", font_size=10)
    ax.set_title("Grafo base: almacén (D) y 4 clientes, distancias en km", fontsize=10, color="#2b1b6b")
    ax.axis("off"); fig.tight_layout(); fig.savefig(archivo); plt.close(fig)

def etiqueta(n):
    u, vis = n
    if u == "D" and not vis: return "D\n{}"
    if u == "D": return "META\nD"
    return f"{u}\n{{{','.join(c[1] for c in sorted(vis))}}}"

def dibujar_entrega_estados(G, camino, archivo):
    capa = {}
    for n in G.nodes:
        capa[n] = 0 if (n[0] == "D" and not n[1]) else (5 if n[0] == "D" else len(n[1]))
    for n, k in capa.items(): G.nodes[n]["layer"] = k
    pos = nx.multipartite_layout(G, subset_key="layer", align="vertical", scale=1.0)
    fig, ax = plt.subplots(figsize=(12, 7.2), dpi=170)
    enc = set(zip(camino, camino[1:]))
    nx.draw_networkx_edges(G, pos, ax=ax, edge_color="#c3bde3", width=0.9, arrows=True, arrowsize=6,
                           node_size=700, connectionstyle="arc3,rad=0.03")
    nx.draw_networkx_edges(G, pos, ax=ax, edgelist=list(enc), edge_color="#e65100", width=2.8, arrows=True,
                           arrowsize=10, node_size=700)
    cols = ["#2e7d32" if capa[n] == 0 else "#c62828" if capa[n] == 5 else ("#ffb300" if n in camino else "#1ab2d9")
            for n in G.nodes]
    nx.draw_networkx_nodes(G, pos, ax=ax, node_color=cols, node_size=700, edgecolors="white")
    nx.draw_networkx_labels(G, pos, {n: etiqueta(n) for n in G.nodes}, ax=ax, font_size=5.6, font_weight="bold")
    ax.set_title("Espacio de estados del reparto: nodo = (ubicación, clientes atendidos), 34 estados y 56 acciones",
                 fontsize=11, fontweight="bold", color="#2b1b6b")
    ax.text(0.01, 0.01, "Verde = estado inicial   Rojo = meta   Ámbar y flechas naranjas = plan óptimo (20 km)   "
            "Columnas = clientes atendidos (0 a 4) y meta", transform=ax.transAxes, fontsize=7.5, color="#444")
    ax.axis("off"); fig.tight_layout(); fig.savefig(archivo); plt.close(fig)

if __name__ == "__main__":
    G1 = m.espacio_metro(); c1, *_ = m.resolver(G1, ("La Paz", "A"), ("Chabacano", "9"))
    dibujar_metro(G1, c1, "Problema 1: espacio de estados del Metro (La Paz -> Chabacano, costo óptimo 35 min)", "fig_metro.png")
    cer = frozenset({("Pantitlán", "9"), ("Puebla", "9"), ("Ciudad Deportiva", "9")})
    G1c = m.espacio_metro(cerrados=cer); c1c, *_ = m.resolver(G1c, ("La Paz", "A"), ("Chabacano", "9"))
    dibujar_metro(G1c, c1c, "Escenario con cierre de Pantitlán, Puebla y Ciudad Deportiva en Línea 9 (costo óptimo 53 min)",
                  "fig_metro_cierre.png", cerrados=cer)
    dibujar_entrega_base("fig_entrega_base.png")
    G2 = m.espacio_entrega(); c2, *_ = m.resolver(G2, m.ESTADO_INICIAL_ENTREGA, ("D", frozenset(m.CLIENTES)))
    dibujar_entrega_estados(G2, c2, "fig_entrega_estados.png")
    print("figuras ok")